# Signalraum V2.1
Telegram bot for receiving signal commands and responding.