# Signalraum bot main script
print('Bot running')