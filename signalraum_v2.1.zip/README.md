# Signalraum V2
This is the core bot.